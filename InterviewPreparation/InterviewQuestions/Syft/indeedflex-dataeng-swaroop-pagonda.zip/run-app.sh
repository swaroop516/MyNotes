#!/bin/bash
echo "Python script execution started"
python /Users/swaroop/MyNotes/InterviewPreparation/InterviewQuestions/Syft/syft-dataeng-swaroop-pagonda.py 
echo "Python script execution completed"
